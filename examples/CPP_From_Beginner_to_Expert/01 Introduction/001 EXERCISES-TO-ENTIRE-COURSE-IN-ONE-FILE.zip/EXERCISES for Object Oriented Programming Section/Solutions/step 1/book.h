#ifndef BOOK_H_INCLUDED
#define BOOK_H_INCLUDED

#include <iostream>

class Book
{
    public:
        std::string title;
        std::string author;
        int publicationYear;
};


#endif // BOOK_H_INCLUDED
