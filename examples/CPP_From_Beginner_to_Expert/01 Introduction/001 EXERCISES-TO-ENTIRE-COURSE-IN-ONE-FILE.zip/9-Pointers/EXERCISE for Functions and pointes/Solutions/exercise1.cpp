#include <iostream>

using namespace std;

int * createArray(int);

int main ()
{

    return 0;
}

int * createArray(int sizeOfArray)
{
    int* newArray = new int[sizeOfArray];

    return newArray;
}

